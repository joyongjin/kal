# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['kal', 'kal.commands', 'kal.core']

package_data = \
{'': ['*']}

install_requires = \
['cleo>=0.8.1,<0.9.0']

entry_points = \
{'console_scripts': ['kal = kal.runner:main']}

setup_kwargs = {
    'name': 'kal',
    'version': '0.0.1',
    'description': 'Personal assistant cli tool',
    'long_description': None,
    'author': 'joyongjin',
    'author_email': 'wnrhd114@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
